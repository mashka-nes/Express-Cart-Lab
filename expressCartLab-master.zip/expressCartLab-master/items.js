module.exports = [
  {
    id: "1",
    product: "BMW",
    price: "50K",
    quantity: "50"
  },
  {
    id: "2",
    product: "Benz",
    price: "$60K",
    quantity: "60"
  },
  {
    id: "3",
    product: "RangeRover",
    price: "$70K",
    quantity: "70"
  },
]